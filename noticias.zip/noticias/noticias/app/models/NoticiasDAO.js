function noticiasDAO(){
	
}

	NoticiasDAO.prototype.getNoticias = function(connection, callback){
		connection.query('select * from noticias', callback); //executa consltas dentro do banco de dados, tal função recebe dois parametros, o sql(consulta em si) e uma função de callback(o que vai ser feito após a consulta ser realizada), a qual espera dois parametros (error, result)
	}

	NoticiasDAO.prototype.getNoticia = function(connection, callback){
		connection.query('select * from noticias where id_noticia = 2', callback);
	}

	NoticiasDAO.prototype.salvarNoticia = function(noticia, connection, callback){
		connection.query('insert into noticias set ?', noticia, callback)
	}

	module.exports = function(){
		return NoticiasDAO;
	}
