module.exports = function(app){ //exporta esta função para o arquivo app, para que os comandos da mesma sejam executados 
	app.get('/', function(req,res){ // requisição da página home.
		res.render("home/index"); //resposta a requisição do servidor, utilizando ejs. Portanto, utilizando o método render, o arquivo que foi requisitado será renderizado. 
	})
}