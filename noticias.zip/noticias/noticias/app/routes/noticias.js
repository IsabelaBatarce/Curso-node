//var dbConnection = require('../../config/dbConnection');

module.exports = function(app){	//exporta esta função para o arquivo app, para que os comandos da mesma sejam executados 
	app.get('/noticias', function(req,res){ //requisição da página noticias

		var connection = app.config.dbConnection();

		var noticiasModel = new app.app.models.NoticiasDAO(connection);

		noticiasModel.getNoticias(connection, function(error,result){
			//console.log(result);
			//res.send(result);
			res.render("noticias/noticias", {noticias: result}); //informa qual a view que renderiza este conteúdo, e posteriormento por meio do json, ou seja, os results serão recebidos na view como se fossem uma variável, podendo acessar essas funções de resultado na view. 
			//res.render("noticias/noticias");
			//res.render("home/index");
		});

	});


};