module.exports = function(app){ //exporta esta função para o arquivo app, para que os comandos da mesma sejam executados 
	app.get('/formulario_inclusao_noticia', function(req,res){ // requisição da página formulario_inclusao_noticia.
		res.render("admin/form_add_noticia"); //resposta a requisição do servidor, utilizando ejs. Portanto, utilizando o método render, o arquivo que foi requisitado será renderizado.
	})
}