module.exports = function(app){ //exporta esta função para o arquivo app, para que os comandos da mesma sejam executados 

	app.get('/noticia', function(req,res){ // requisição da página noticia.

		var connection = app.config.dbConnection();
		var noticiasModel = new app.app.models.noticiasModel.NoticiasDAO(connection);

		noticiasModel.getNoticia(connection, function(error,result){
			res.render("noticias/noticia", {noticia: result});
		});

	});
};