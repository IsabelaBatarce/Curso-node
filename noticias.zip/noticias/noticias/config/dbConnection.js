var mySql = require('mySql'); //incorpora o modulo que  permite a conexão com o banco de dados

 

var connMySql = function () {
	console.log('Conexão com o banco de dados foi estabelecida.')
	return mySql.createConnection({ //estabelendo a conexão com o banco, por meio de alguns parâmetros(passados em uma estrutura json) para efetuar essa conexão no banco
		host: 'localhost', //combinação de chave e valor - host é um endereço do servidor, o qual esta instalado na máquina 
		user: 'root', //combinação de chave e valor - user(usuário) será root
		password: '', //combinação de chave e valor - senha
		database: 'portal_noticiasa' //combinação de chave e valor - nome do database
	});

}

module.exports = function(){
	console.log('O autoload carregou o módulo de conexão com o banco de dados.')
	return connMySql;
}