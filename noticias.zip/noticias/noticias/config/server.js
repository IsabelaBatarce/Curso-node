var express = require('express'); //require é uma função js que permite incorporar outros arquivos, neste caso está incorporando a biblioteca do express.
var consign = require('consign'); //require é uma função js que permite incorporar outros arquivos.
var bodyParser = require('body-parser');

var app = express();  //executando a função que o módulo do express retorna 
app.set('view engine', 'ejs'); // para indicar ao express que estamos utilizando ejs para gerar views
app.set('views', './app/views'); //diretório de views padrão, aponta ao ejs onde está o caminho de views

app.use(bodyParser.urlencoded({extended:true}));

consign()
	.include('app/routes')
	.then('config/dbConnection.js')
	.then('app/models')
	.into(app);

module.exports = app; //retorna a variável app