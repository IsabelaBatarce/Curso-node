var app = require('./config/server'); //require é uma função js que permite incorporar outros arquivos, neste caso está incorporando o arquivo server.js



app.listen(3000, function(){ 
	console.log("Servidor ON"); // subir um servidor que escuta requisições da porta 3000. E executando uma função de calllback. 
